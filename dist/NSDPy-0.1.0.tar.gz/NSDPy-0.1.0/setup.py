# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['nsdpy']
entry_points = \
{'console_scripts': ['NSDPy = entry:main']}

setup_kwargs = {
    'name': 'nsdpy',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'RaphaelHebert',
    'author_email': 'raphaelhebert18@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'entry_points': entry_points,
    'python_requires': '==3.8.5',
}


setup(**setup_kwargs)
