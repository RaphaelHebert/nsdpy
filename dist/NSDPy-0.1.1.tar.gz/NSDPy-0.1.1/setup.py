# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['nsdpy']
install_requires = \
['certifi==2020.12.5',
 'chardet==4.0.0',
 'idna==2.10',
 'requests==2.25.1',
 'urllib3==1.26.2']

entry_points = \
{'console_scripts': ['NSDPy = entry:main']}

setup_kwargs = {
    'name': 'nsdpy',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'RaphaelHebert',
    'author_email': 'raphaelhebert18@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '==3.8.5',
}


setup(**setup_kwargs)
